%% sector_example
input_wp_filename='zigzag1.txt';

lonfirst=true;

outfilename='sector1.csv';
sector(input_wp_filename,outfilename,lonfirst);